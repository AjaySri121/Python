name = []

def add_name():
 print("1. View Names")
 
def view_name():
 print("2. Add new name")
 
def remove_name():
 print("3. Delete Last name entered")
 
def deleting_any_name():
 print("4. Delete any name")
 
def leave_system():
 print("5. Exit")
 
 
while True:
 try:
   add_name()
   view_name()
   remove_name()
   deleting_any_name()
   leave_system()
   choice = int(input("Enter the selection: "))
   print("")
 except ValueError:
   print("Input a number from 1-5 please!")
   continue
 if choice == 1:
   for i in name:
     print(i)
   print(" ")
 elif choice == 2:
   try:
     name2 = input("Enter a new name:")
     name.append(name2)
   except ValueError:
     print("Print a number please!")
   print("")
 elif choice == 3:
   try:
     subtract = len(name) - 1
     del name [subtract]
     print(name2 + "<:Deleted successfully")
     print("")
   except:
     print("List is empty, please add the name first.") 
 elif choice == 4:
   try:
     delete_name = input("Enter a name to be deleted: ")
     name.remove(delete_name)
     print(delete_name + "<:Deleted successfully")
   except ValueError:
     print("This does not exist, try again later.")
   print("")
 else:
   print("Goodbye! Have a nice day:>")
   break
