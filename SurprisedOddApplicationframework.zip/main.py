from tkinter import *

root = Tk()

def instructions():
  myLabel = Label(root, text = "Follow the following instructions about our application: \n 1) Move your cursor to the top this window. Press on it and slide it down to see our application. \n 2) When you see our Control Window, you can start using our application. Click start to start the game. \n 3) Slide the Control Window similar to how you did for the tk window and have FUN! " )
  myLabel.pack()

myButton = Button(root, text = "Welcome to Soccer Scoreboard! \n Click here to learn how our application works", padx = 50, command=instructions)
myButton.pack()
root.mainloop()