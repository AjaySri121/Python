def retrieve_positive_number():
  question = int(input("Enter a positive number: "))
  return question
  try:
    while True:
      question = int(input("Enter a positive number: "))
      if question >0:
        print("Nice number!")
        question
      else:
        print("Enter a positive number!")
  except ValueError:
    print("Write an actual positive number please!")
print(retrieve_positive_number())